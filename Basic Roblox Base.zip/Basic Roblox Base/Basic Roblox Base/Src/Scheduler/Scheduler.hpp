#include <lobject.h>
#include <Vector>
#include <lapi.h>
#include <Addresses.h>



namespace Scheduler
{

    uintptr_t GetDataModel() {
        uintptr_t fakeDM = *(uintptr_t*)Addresses::Update::FakeDataModel;

        return *(uintptr_t*)(fakeDM + Addresses::offsets::FakeDataModelToDataModel);
    }


    uintptr_t GetScriptContext() {
        uintptr_t dataModel = GetDataModel();
        if (!dataModel) {

            return 0;
        }

        uintptr_t children = *(uintptr_t*)(dataModel + 0x80);
        uintptr_t start = *(uintptr_t*)(children + 0x0);
        uintptr_t end = *(uintptr_t*)(children + 0x8);

        for (uintptr_t ptr = start; ptr < end; ptr += sizeof(uintptr_t)) {
            uintptr_t instance = *(uintptr_t*)ptr;
            if (!instance) continue;

            uintptr_t classDesc = *(uintptr_t*)(instance + 0x18);
            if (!classDesc) continue;

            const char* name = *(const char**)(classDesc + 0x8);
            if (!name) continue;

            if (strcmp(name, "ScriptContext") == 0) {
                return instance;
            }
        }


        return 0;
    }

    uintptr_t GlobalState() {
        auto ScriptContext = GetScriptContext();
        uintptr_t GlobalState = ScriptContext + Addresses::offsets::GlobalState;
        return GlobalState;
    }


    std::vector<uintptr_t> get_all_jobs() {
        std::vector<uintptr_t> jobs;

        auto jobs_start = *(uintptr_t**)(Addresses::Update::task_scheduler + Addresses::offsets::job_start);
        auto jobs_end = *(uintptr_t**)(Addresses::Update::task_scheduler + Addresses::offsets::job_start + sizeof(void*));

        for (auto job = jobs_start; job != jobs_end; job += 2)
            jobs.push_back(*job);

        return jobs;
    }

    std::vector<uintptr_t> get_jobs_by_name(const std::string& name)
    {
        std::vector<uintptr_t> matched;

        for (auto& job : get_all_jobs())
            if (auto jobname = (std::string*)(job + Addresses::offsets::job_name); *jobname == name)
                matched.push_back(job);

        return matched;
    }



    uintptr_t get_lua_state(uintptr_t identity, uintptr_t script)
    {
        uintptr_t excluded_job = 0;

        for (auto& job : get_jobs_by_name("WaitingHybridScriptsJob")) {
            auto ctx = *(uintptr_t*)(job + Addresses::offsets::script_context_job);

            uintptr_t state = roblox::get_global_state(ctx + Addresses::offsets::GlobalState, &identity, &script);
            auto lua_state = roblox::decrypt_lua_state(state + Addresses::offsets::decrypt_state);

            lua_pushvalue((lua_State*)(lua_state), LUA_REGISTRYINDEX);
            auto reg_table = hvalue(index2addr((lua_State*)(lua_state), -1));

            if (reg_table->sizearray == 4) {
                excluded_job = job;
            }
        }

        for (auto& job : get_jobs_by_name("WaitingHybridScriptsJob")) {
            if (job != excluded_job) {
                const auto encrypted_state = roblox::get_global_state(*(uintptr_t*)(job + Addresses::offsets::script_context_job) + Addresses::offsets::GlobalState, &identity, &script);
                return roblox::decrypt_lua_state(encrypted_state + Addresses::offsets::decrypt_state);
            }
        }

        return 0;
    }
}
