namespace States {
	inline lua_State* roblox_state;
	inline lua_State* API_state;

}
