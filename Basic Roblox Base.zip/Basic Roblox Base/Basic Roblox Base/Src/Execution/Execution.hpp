#include <../Scheduler/Scheduler.hpp>
inline uintptr_t max_caps = 0xEFFFFFFFFFFFFFFF;

void set_thread_lvl(lua_State* l, int lvl, uintptr_t c)
{
	auto extra_space = (uintptr_t)(l->userdata);
	*(uintptr_t*)(extra_space + 0x48) = c;
	*(uintptr_t*)(extra_space + 0x30) = lvl;
}
void set_proto_capabilities(Proto* proto, uintptr_t* c)
{
	if (!proto) return;

	proto->userdata = c;
	for (int i = 0; i < proto->sizep; ++i)
		set_proto_capabilities(proto->p[i], c);

}
class bytecode_encoder_t : public Luau::BytecodeEncoder {
	inline void encode(uint32_t* data, size_t count) override {

		for (auto i = 0u; i < count;) {

			auto& opcode = *(uint8_t*)(data + i);

			i += Luau::getOpLength(LuauOpcode(opcode));

			opcode *= 227;
		}
	}
};

static std::string compress_bytecode(const std::string_view bytecode)
{
	const auto data_size = bytecode.size();
	const auto max_size = ZSTD_compressBound(data_size);
	auto buffer = std::vector<char>(max_size + 8);

	strcpy_s(&buffer[0], buffer.capacity(), "RSB1");
	memcpy_s(&buffer[4], buffer.capacity(), &data_size, sizeof(data_size));

	const auto compressed_size = ZSTD_compress(&buffer[8], max_size, bytecode.data(), data_size, ZSTD_maxCLevel());
	if (ZSTD_isError(compressed_size))
		return "";

	const auto size = compressed_size + 8;
	const auto key = XXH32(buffer.data(), size, 42u);
	const auto bytes = (const uint8_t*)(&key);

	for (auto i = 0u; i < size; ++i)
		buffer[i] ^= bytes[i % 4] + i * 41u;

	return std::string(buffer.data(), size);
}


void execute(lua_State* l, const std::string& script)
{
	static bytecode_encoder_t encoder;

	std::string full_script = std::string("script = Instance.new('LocalScript');") + script;
	std::string bytecode = Luau::compile(full_script, { 1, 1, 0 }, {}, &encoder);
	std::string compressed = compress_bytecode(bytecode);

	if (bytecode.empty() || bytecode[0] == 0)
	{
		roblox::r_print(3, bytecode.c_str() + 1);
		return;
	}

	lua_settop(l, 0);
	lua_State* new_thread = lua_newthread(l);

	luaL_sandboxthread(new_thread);

	if (roblox::luavm_load((int64_t)(new_thread), &compressed, "@Vexus", 0) != LUA_OK)
	{

		const char* err_msg = lua_tostring(new_thread, -1);
		roblox::r_print(2, "%s", err_msg);
		lua_pop(new_thread, 1);
		lua_pop(l, 1);
		return;
	}

	Closure* closure = (Closure*)(lua_topointer(new_thread, -1));

	if (closure && closure->l.p)
	{
		set_proto_capabilities(closure->l.p, &max_caps);
	}

	lua_getglobal(l, "task");
	lua_getfield(l, -1, "defer");
	lua_remove(l, -2);
	lua_xmove(new_thread, l, 1);
	lua_pcall(l, 1, 0, 0);

	lua_settop(new_thread, 0);
	lua_pop(l, 1);
}