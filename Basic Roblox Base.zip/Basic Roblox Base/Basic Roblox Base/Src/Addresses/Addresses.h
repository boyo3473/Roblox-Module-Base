#pragma once

#include <Windows.h>
#include <iostream>
#include <vector>

#include "../../Dependencies/Luau/VM/include/lua.h"
#include <lobject.h>



#define Rebase(x) (x + (uintptr_t)(GetModuleHandle(nullptr)))

namespace Addresses
{
	namespace Update
	{
		const uintptr_t print = Rebase(0x1563AC0);
		const uintptr_t task_scheduler = Rebase(0x681CA18);
		const uintptr_t luavm_load = Rebase(0xB47780);
		const uintptr_t luad_throw = Rebase(0x2741980);


		const uintptr_t FakeDataModel = Rebase(0x675AA38);

		const uintptr_t get_global_state = Rebase(0xDBD570);
		const uintptr_t decrypt_lua_state = Rebase(0xB44700);
	}

	namespace offsets 
	{

		const uintptr_t FakeDataModelToDataModel = 0x1B8;
		const uintptr_t PlaceId = 0x1A0;
		const uintptr_t ScriptContext = 0x3B0;

		const uintptr_t GlobalState = 0x140;


		const uintptr_t job_start = 0x1D8;
		const uintptr_t job_name = 0x18;


		const uintptr_t script_context_job = 0x1F8;

		const uintptr_t decrypt_state = 0x88;

	}
}

namespace roblox
{

	inline __int64 GetThreadIdentity(uintptr_t L) {
		uintptr_t Userdata = *(uintptr_t*)(L + 0x78);
		return *(__int64*)(Userdata + 0x30);
	}

	inline void SetThreadIdentity(uintptr_t L, uintptr_t Identity) {
		uintptr_t Userdata = *(uintptr_t*)(L + 0x78);
		*(__int64*)(Userdata + 0x30) = Identity;
	}

	using print_func_t = int(__fastcall*)(int, const char*, ...);
	inline print_func_t r_print = reinterpret_cast<print_func_t>(Addresses::Update::print);

	using get_global_state_t = uintptr_t(__fastcall*)(uintptr_t, uintptr_t*, uintptr_t*);
	inline get_global_state_t get_global_state = reinterpret_cast<get_global_state_t>(Addresses::Update::get_global_state);

	using decrypt_lua_state_t = uintptr_t(__fastcall*)(uintptr_t);
	inline decrypt_lua_state_t decrypt_lua_state = reinterpret_cast<decrypt_lua_state_t>(Addresses::Update::decrypt_lua_state);

	using luavm_load_t = uintptr_t(__fastcall*)(int64_t, std::string*, const char*, int);
	inline luavm_load_t luavm_load = reinterpret_cast<luavm_load_t>(Addresses::Update::luavm_load);

	using luad_throw_t = void(__fastcall*)(lua_State*, int);
	inline luad_throw_t luad_throw = reinterpret_cast<luad_throw_t>(Addresses::Update::luad_throw);


}

