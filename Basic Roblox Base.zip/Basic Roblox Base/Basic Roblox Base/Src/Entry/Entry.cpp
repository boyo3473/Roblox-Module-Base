#include <thread>
#include <chrono>
#include <atomic>
#include <Windows.h>

#include <Addresses/Addresses.h>
#include "VM/src/lstate.h"
#include "../../Dependencies/Luau/VM/src/lapi.h"
#include "../../Dependencies/Luau/Compiler/include/Luau/BytecodeBuilder.h"
#include "VM/src/lobject.h"
#include <lualib.h>
#include <BytecodeUtils.h>
#include <Compiler.h>
#include "../../Dependencies/zstd/include/zstd/zstd.h"
#include "../../Dependencies/zstd/include/zstd/xxhash.h"
#include <Execution/Execution.hpp>
#include "../Globals/Globals.hpp"


void Entry() 
{
	States::roblox_state = (lua_State*)(Scheduler::get_lua_state(0, 0));
	States::API_state = lua_newthread(States::roblox_state);
	set_thread_lvl(States::API_state, 8, 0xEFFFFFFFFFFFFFFF);
	luaL_sandboxthread(States::API_state);


	//only executes 1 thing but you can add a pipe or what ever
	execute(States::API_state, "print('hello From Base!')");



}

BOOL APIENTRY DllMain(HMODULE module, DWORD  call_reason, LPVOID reserved) {
	if (call_reason == DLL_PROCESS_ATTACH) {
		DisableThreadLibraryCalls(module);


		std::thread(Entry).detach();

	}
	return TRUE;
}
